console.log("helloworld");

fetch("/flowers2019").then((response)=>{
	return response.json();
}).then((response)=>{
	console.log(response);
	var list = document.getElementById('allflower');

	for (let i = 0; i<response.length;i++){
	
		let cn = document.createElement("li");
		cn.innerText = "COMNAME";

		let genus = document.createElement("li");
		genus.innerText = "GENUS";

		let species = document.createElement("li");
		species.innerText = "SPECIES";

		let listpart = document.createElement("li");
		let updateb = document.createElement("button");
		updateb.innerText = "UPDATE";
		

		let updateComnname = document.createElement("input");
		let updateGenus = document.createElement("input");
		let updateSpecies = document.createElement("input");

		updateb.innerText = "UPDATE";
		
		listpart.innerText = response[i]["COMNAME"];

		listpart.onclick = ()=> {
			flowerstats(response[i]["COMNAME"]);
		};
	
		updateb.onclick = () => {
			update(response[i]["COMNAME"],updateComnname.value,updateSpecies.value,updateGenus.value);

		};


		list.appendChild(listpart);
	
		list.appendChild(cn);
		list.appendChild(updateComnname);
		list.appendChild(species);
		list.appendChild(updateSpecies);
		list.appendChild(genus);
		list.appendChild(updateGenus);
		list.appendChild(updateb);
	};

	var input = document.getElementById('insertion');
	var brack = document.createElement("br");
	var insertb = document.createElement("button");
	insertb.innerText = "INSERT"
	var insertName = document.createElement("input");
	var insertPerson = document.createElement("input");
	var insertLocation = document.createElement("input");
	var insertSighted = document.createElement("input");
	insertSighted.type = "date";


	var name = document.createElement("li");
	name.innerText = "NAME";

	var person = document.createElement("li");
	person.innerText = "PERSON";

	var location = document.createElement("li");
	location.innerText = "LOCATION";

	var sighted = document.createElement("li");
	sighted.innerText = "SIGHTED";


	insertb.onclick = ()=>{

		insert(insertName.value,insertPerson.value,insertLocation.value,insertSighted.value);		

	};




	input.appendChild(insertb);
	input.appendChild(brack);
	input.appendChild(name);
	input.appendChild(insertName);
	input.appendChild(person);
	input.appendChild(insertPerson);
	input.appendChild(location);
	input.appendChild(insertLocation);
	input.appendChild(sighted);
	input.appendChild(insertSighted);

});

function flowerstats(COMNAME) {
fetch("/sightings/" + COMNAME).then((response)=>{
	return response.json();
}).then((response)=> {
	console.log(response);
	var statlist = document.getElementById('statistics');

	

	var stattypes = ["NAME", "PERSON", "LOCATION","SIGHTED"];
	for (let i = 0; i < response.length; i++){
		var sightpart = document.createElement("li");
		sightpart.innerText = "";
		
		for(let k = 0; k < stattypes.length; k++){

			sightpart.innerText = sightpart.innerText + " "+ response[i][stattypes[k]];



		}
		statlist.appendChild(sightpart);

	}


});
};

function update(COMNAME,NEWCOMNAME, NEWSPECIES, NEWGENUS) {
	
	let data = {
		nComname: NEWCOMNAME,
		nSpecies: NEWSPECIES,
		nGenus: NEWGENUS
	}
	console.log(data);
	fetch("/update/" + COMNAME,{
		method: 'POST',
		
		body: JSON.stringify(data),
		headers: {
			'Content-Type': 'application/json'
		}


	});

 



};

function insert(NAME, PERSON, LOCATION, SIGHTED){
	
	let data = {
		name: NAME,
		person: PERSON,
		location: LOCATION,
		sighted: SIGHTED
	}
	console.log(data);
	fetch("/insertsight/" + NAME,{
		method: 'POST',
		body: JSON.stringify(data),
		headers:{
			'Content-Type':'application/json'
		}

	});


};