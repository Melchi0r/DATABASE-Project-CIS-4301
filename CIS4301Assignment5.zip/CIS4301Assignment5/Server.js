const express = require('express');
var sqlite3 = require('sqlite3').verbose();
const app = express();

var db = new sqlite3.Database('flowers2019.db');

app.use(express.json());

app.get('/flowers2019',(req,res)=> {
	db.all("Select * From FLOWERS",[] ,function(err, rows) {
		res.send(rows);
	} );

});
app.get('/sightings/:COMNAME',(req,res)=>{
	console.log(req.params.COMNAME);
	db.all("Select * From Sightings Where Sightings.Name = ? Order By Sighted Desc Limit 10 ", [req.params.COMNAME], function(err,rows){

		res.send(rows);
	});

});

app.post('/update/:COMNAME', (req,res)=>{
	console.log(req.body);
	let newvalues = req.body;
	console.log(req.params.COMNAME);
	if(newvalues["nGenus"] != ""){
		db.run("UPDATE FLOWERS SET GENUS = ? WHERE COMNAME = ?",[newvalues["nGenus"], req.params.COMNAME]);
	};
	if(newvalues["nSpecies"] != ""){
		db.run("UPDATE FLOWERS SET SPECIES = ? WHERE COMNAME = ?",[newvalues["nSpecies"], req.params.COMNAME]);
	};
	if(newvalues["nComname"] != ""){
		db.run("UPDATE SIGHTINGS SET NAME = ? WHERE NAME = ?",[newvalues["nComname"], req.params.COMNAME]);
		db.run("UPDATE FLOWERS SET COMNAME = ? WHERE COMNAME = ?",[newvalues["nComname"], req.params.COMNAME]);
	};
	res.send();
});


app.post('/insertsight/:NAME',(req,res)=>{
	console.log(req.body);
	let insertvalues = req.body;
	if(insertvalues["name"] != "" && insertvalues["person"] != "" && insertvalues["location"] != "" && insertvalues["sighted"] != ""){
		db.run("INSERT or IGNORE INTO SIGHTINGS VALUES (?,?,?,?);",[insertvalues["name"],insertvalues["person"],insertvalues["location"],insertvalues["sighted"]]);
	};
	res.send();
});


app.use(express.static('Frontend'));

app.listen(80, () => console.log('Starting server'));